import { Component } from '@angular/core';

@Component({
  selector: 'app-events-card-list',
  imports: [],
  templateUrl: './events-card-list.html',
  styleUrl: './events-card-list.css',
})
export class EventsCardList {

}
