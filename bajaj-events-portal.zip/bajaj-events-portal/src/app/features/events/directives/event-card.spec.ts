import { EventCard } from './event-card';

describe('EventCard', () => {
  it('should create an instance', () => {
    const directive = new EventCard();
    expect(directive).toBeTruthy();
  });
});
