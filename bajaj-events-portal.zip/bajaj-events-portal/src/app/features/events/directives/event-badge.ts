import { Directive } from '@angular/core';

@Directive({
  selector: '[appEventBadge]'
})
export class EventBadge {

  constructor() { }

}
