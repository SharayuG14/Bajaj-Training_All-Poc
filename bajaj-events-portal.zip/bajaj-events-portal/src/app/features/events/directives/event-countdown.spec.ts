import { EventCountdown } from './event-countdown';

describe('EventCountdown', () => {
  it('should create an instance', () => {
    const directive = new EventCountdown();
    expect(directive).toBeTruthy();
  });
});
