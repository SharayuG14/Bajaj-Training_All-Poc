import { Component } from '@angular/core';

@Component({
  selector: 'app-ep-home',
  imports: [],
  templateUrl: './ep-home.html',
  styleUrl: './ep-home.css',
})
export class EpHome {

}
