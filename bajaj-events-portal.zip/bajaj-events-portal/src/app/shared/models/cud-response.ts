export interface CudResponse {
    acknowledged:boolean;
}
