import { LowercaseTrunkPipe } from './lowercase-trunk-pipe';

describe('LowercaseTrunkPipe', () => {
  it('create an instance', () => {
    const pipe = new LowercaseTrunkPipe();
    expect(pipe).toBeTruthy();
  });
});
